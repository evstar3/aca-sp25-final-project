extern void exitPGP(int);
