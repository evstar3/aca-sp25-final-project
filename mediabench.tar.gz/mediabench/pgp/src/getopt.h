#ifndef UNIX	/* avoid conflict with stdlib.h */
int pgp_getopt(int argc, char **argv, char *opts);
#endif

