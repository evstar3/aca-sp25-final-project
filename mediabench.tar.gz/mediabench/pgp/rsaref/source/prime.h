/* PRIME.H - header file for PRIME.C
 */

/* Copyright (C) 1991-2 RSA Laboratories, a division of RSA Data
   Security, Inc. All rights reserved.
 */

void FindRSAPrime PROTO_LIST 
  ((NN_DIGIT *, unsigned int, NN_DIGIT *, unsigned int, NN_DIGIT *,
    unsigned int));
