int flushArmour(FILE * stream);
size_t freadPlus(void *ptr, size_t size, size_t n, FILE *stream);
size_t fwritePlus(const void *ptr, size_t size, size_t n, FILE *stream);
int fputcPlus(int c, FILE *stream);
void burnBinasc(void);
